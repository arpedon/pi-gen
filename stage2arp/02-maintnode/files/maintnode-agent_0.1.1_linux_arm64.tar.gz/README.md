# MaintNode agent

MaintNode agent is responsible for managing and configuring a MaintNode. Currently, it supports continuously checking for a new configuration and updating it, while it will do more things in the future.

## Usage

```shell
maintnode-agent https://mechbase.arpedon.com/api/maintnode-configs/:uuid-here /path/to/save/config
```

## Installation

1. Copy the [latest release binary](https://github.com/arpedon/maintnode-agent/releases/latest) to `/usr/local/bin/maintnode-agent`
1. Copy the [`system/maintnode-agent.service](system/maintnode-agent.service) file to `/etc/systemd/system/maintnode-agent.service`
1. Change the UUID and path, if needed
1. Enable and start the service
   ```shell
   sudo systemctl daemon-reload
   sudo systemctl enable maintnode-agent
   sudo systemctl start maintnode-agent
   ```
